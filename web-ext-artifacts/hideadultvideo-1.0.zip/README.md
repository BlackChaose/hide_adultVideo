# hide_adultVideo
This is my probe of firefox extension, first version of one more variant of parents control
